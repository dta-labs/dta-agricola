Protothreads can in some cases fail to compile under Visual C++
version 6.0 due to a bug in the compiler. See the following page for a
solution to the problem:

http://support.microsoft.com/default.aspx?scid=kb;en-us;199057
