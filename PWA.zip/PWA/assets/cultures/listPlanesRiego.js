// let frijol = import("./frijol.js");
import frijol from ("./frijol.js");

var listPlanesRiego = [
    { culture: "Maíz", detail: "", price: "0.00", plan: [] },
    { culture: "Frijol", detail: "", price: "0.00", plan: frijol },
    { culture: "Algodón", detail: "", price: "0.00", plan: [] },
    { culture: "Papa", detail: "", price: "99.99", plan: [] },
    { culture: "Papa", detail: "Invierno", price: "99.99", plan: [] },
    { culture: "Avena", detail: "", price: "99.99", plan: [] },
    { culture: "Cebada", detail: "", price: "99.99", plan: [] },
    { culture: "Sorgo", detail: "", price: "99.99", plan: [] },
    { culture: "Cacao", detail: "", price: "99.99", plan: [] },
    { culture: "Apio", detail: "", price: "99.99", plan: [] },
    { culture: "Lechuga", detail: "", price: "99.99", plan: [] },
    { culture: "Zanahoria", detail: "", price: "99.99", plan: [] },
    { culture: "Repollo", detail: "", price: "99.99", plan: [] },
    { culture: "Brócoli", detail: "", price: "99.99", plan: [] },
    { culture: "Café", detail: "", price: "99.99", plan: [] }
];
