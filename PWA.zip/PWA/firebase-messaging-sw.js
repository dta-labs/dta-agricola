importScripts("https://www.gstatic.com/firebasejs/5.10.1/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/5.10.1/firebase-messaging.js");
importScripts("assets/js/firebaseInit.js");

firebase.messaging();
