// import { initializeApp } from "https://www.gstatic.com/firebasejs/9.10.0/firebase-app.js";

var config = {
    apiKey: "AIzaSyCMQrfX00C0DuaYCUugYPDsPSo-a-0nqNA",
    authDomain: "dta-agricola.firebaseapp.com",
    databaseURL: "https://dta-agricola.firebaseio.com",
    projectId: "dta-agricola",
    storageBucket: "dta-agricola.appspot.com",
    messagingSenderId: "157203634312",
    appId: "1:157203634312:web:95003cad8bc5a95151a73d",
    measurementId: "G-51FCCVQT6B"
};

// export const firebase = initializeApp(config);

